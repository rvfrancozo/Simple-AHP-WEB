<?php $__env->startSection('menu'); ?>

<ul class="navbar-nav mr-auto">

	<?php if(auth()->guard()->guest()): ?>
	<?php if(Route::has('login')): ?>
	<?php endif; ?>

	<?php if(Route::has('register')): ?>
	<?php endif; ?>
	<?php else: ?>

	<li class="nav-item">
		<form method="GET" action="/nodes">
			<?php echo csrf_field(); ?>
			<button style="border:none;background-color:transparent" type="submit" class="nav-link">My Decision Problems</button>
		</form>
	</li>
	&nbsp;&nbsp;&nbsp;&nbsp;
	<li>
		<form method="POST" action="/formCreateNode/0">
			<?php echo csrf_field(); ?>
			<button style="border:none;background-color:transparent" type="submit" class="nav-link">New Decision Problem</button>
		</form>
	</li>
	<?php endif; ?>

</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/social.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/social-icons.css')); ?>" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="/css/bootstrap.min.css">
<h3><i>Simple</i> - AHP</h3>
<p>AHP (Analytic Hierarchy Process)</p>
<p>A widely used multi-criteria method, developed by Dr. Thomas L. Saaty (1980);</p>
<p>AHP divides the decision problem into hierarchical levels, thus facilitating its understanding and evaluation.</p>
<p></p>

<!-- <div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="chart-wrapper">
				<canvas id="myChart"></canvas>
			</div>
		</div>
	</div>
</div>


<script>
	const ctx = document.getElementById('myChart');
	const myChart = new Chart(ctx, {
		type: 'bar',
		data: {
			labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
			datasets: [{
				label: '# of Votes',
				data: [1, 19, 3, 5, 2, 3],
				backgroundColor: [
					'rgba(255, 99, 132, 0.2)',
					'rgba(54, 162, 235, 0.2)',
					'rgba(255, 206, 86, 0.2)',
					'rgba(75, 192, 192, 0.2)',
					'rgba(153, 102, 255, 0.2)',
					'rgba(255, 159, 64, 0.2)'
				],
				borderColor: [
					'rgba(255, 99, 132, 1)',
					'rgba(54, 162, 235, 1)',
					'rgba(255, 206, 86, 1)',
					'rgba(75, 192, 192, 1)',
					'rgba(153, 102, 255, 1)',
					'rgba(255, 159, 64, 1)'
				],
				borderWidth: 1
			}]
		},
		options: {
			responsive: true,
			maintainAspectRatio: false,
			scales: {
				yAxes: [{
					ticks: {
						beginAtZero: true
					}
				}]
			}
		}
	});
</script> -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/welcome.blade.php ENDPATH**/ ?>