<?php $__env->startSection('menu'); ?>

<ul class="navbar-nav mr-auto">

    <?php if(auth()->guard()->guest()): ?>
    <?php if(Route::has('login')): ?>
    <?php endif; ?>

    <?php if(Route::has('register')): ?>
    <?php endif; ?>
    <?php else: ?>

    <li class="nav-item">
        <form method="GET" action="/nodes">
            <?php echo csrf_field(); ?>
            <button style="border:none;background-color:transparent" type="submit" class="nav-link">My Decision Problems</button>
        </form>
    </li>
    &nbsp;&nbsp;&nbsp;&nbsp;
    <li>
        <form method="POST" action="/formCreateNode/0">
            <?php echo csrf_field(); ?>
            <button style="border:none;background-color:transparent" type="submit" class="nav-link">New Decision Problem</button>
        </form>
    </li>
    <?php endif; ?>

</ul>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('conteudo'); ?>
<?php
$i = 0;
$score = array(1 / 9, 1 / 8, 1 / 7, 1 / 6, 1 / 5, 1 / 4, 1 / 3, 1 / 2);
?>
<form method="POST" action="/dmweights/<?php echo e($goal->id); ?>">
    <?php echo csrf_field(); ?>
    <hr><b>For <i><?php echo e($goal->descr); ?></i> decision problem...</b>

    <table class="table">
        <tbody>
            <tr>
                <td><?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?> x <?php echo e(substr(Auth::user()->email,0,strpos(Auth::user()->email, '@') )); ?></td>
                <td>
                    <select name="score<?php echo e($i++); ?>" class="custom-select">
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;0;<?php echo e(1/9); ?>">9 - <?php echo e(substr(Auth::user()->email,0,strpos(Auth::user()->email, '@') )); ?> is 9x most important than <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;0;<?php echo e(1/8); ?>">1/8 - <?php echo e(substr(Auth::user()->email,0,strpos(Auth::user()->email, '@') )); ?> is 8x most important than <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;0;<?php echo e(1/7); ?>">1/7 - <?php echo e(substr(Auth::user()->email,0,strpos(Auth::user()->email, '@') )); ?> is 7x most important than <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;0;<?php echo e(1/6); ?>">1/6 - <?php echo e(substr(Auth::user()->email,0,strpos(Auth::user()->email, '@') )); ?> is 6x most important than <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;0;<?php echo e(1/5); ?>">1/5 - <?php echo e(substr(Auth::user()->email,0,strpos(Auth::user()->email, '@') )); ?> is 5x most important than <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;0;<?php echo e(1/4); ?>">1/4 - <?php echo e(substr(Auth::user()->email,0,strpos(Auth::user()->email, '@') )); ?> is 4x most important than <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;0;<?php echo e(1/3); ?>">1/3 - <?php echo e(substr(Auth::user()->email,0,strpos(Auth::user()->email, '@') )); ?> is 3x most important than <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;0;<?php echo e(1/2); ?>">1/2 - <?php echo e(substr(Auth::user()->email,0,strpos(Auth::user()->email, '@') )); ?> is 2x most important than <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?></option>
                        <option selected value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;<?php echo e(Auth::user()->id); ?>;1">1 - <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?> is equal to <?php echo e(substr(Auth::user()->email,0,strpos(Auth::user()->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;0;2">2 - <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?> is 2x most important than <?php echo e(substr(Auth::user()->email,0,strpos(Auth::user()->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;0;3">3 - <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?> is 3x most important than <?php echo e(substr(Auth::user()->email,0,strpos(Auth::user()->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;0;4">4 - <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?> is 4x most important than <?php echo e(substr(Auth::user()->email,0,strpos(Auth::user()->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;0;5">5 - <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?> is 5x most important than <?php echo e(substr(Auth::user()->email,0,strpos(Auth::user()->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;0;6">6 - <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?> is 6x most important than <?php echo e(substr(Auth::user()->email,0,strpos(Auth::user()->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;0;7">7 - <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?> is 7x most important than <?php echo e(substr(Auth::user()->email,0,strpos(Auth::user()->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;0;8">8 - <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?> is 8x most important than <?php echo e(substr(Auth::user()->email,0,strpos(Auth::user()->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;0;9">9 - <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?> is 9x most important than <?php echo e(substr(Auth::user()->email,0,strpos(Auth::user()->email, '@') )); ?></option>
                    </select>
                </td>
            </tr>
            <?php $__currentLoopData = $dms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?> x <?php echo e(substr($dm->email,0,strpos($dm->email, '@') )); ?></td>
                <td>
                    <select name="score<?php echo e($i); ?>" class="custom-select">
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;<?php echo e($dm->id); ?>;<?php echo e(1/9); ?>">1/9 - <?php echo e(substr($dm->email,0,strpos($dm->email, '@') )); ?> is 9x most important than <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;<?php echo e($dm->id); ?>;<?php echo e(1/8); ?>">1/8 - <?php echo e(substr($dm->email,0,strpos($dm->email, '@') )); ?> is 8x most important than <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;<?php echo e($dm->id); ?>;<?php echo e(1/7); ?>">1/7 - <?php echo e(substr($dm->email,0,strpos($dm->email, '@') )); ?> is 7x most important than <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;<?php echo e($dm->id); ?>;<?php echo e(1/6); ?>">1/6 - <?php echo e(substr($dm->email,0,strpos($dm->email, '@') )); ?> is 6x most important than <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;<?php echo e($dm->id); ?>;<?php echo e(1/5); ?>">1/5 - <?php echo e(substr($dm->email,0,strpos($dm->email, '@') )); ?> is 5x most important than <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;<?php echo e($dm->id); ?>;<?php echo e(1/4); ?>">1/4 - <?php echo e(substr($dm->email,0,strpos($dm->email, '@') )); ?> is 4x most important than <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;<?php echo e($dm->id); ?>;<?php echo e(1/3); ?>">1/3 - <?php echo e(substr($dm->email,0,strpos($dm->email, '@') )); ?> is 3x most important than <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;<?php echo e($dm->id); ?>;<?php echo e(1/2); ?>">1/2 - <?php echo e(substr($dm->email,0,strpos($dm->email, '@') )); ?> is 2x most important than <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?></option>
                        <option selected value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;<?php echo e($dm->id); ?>;1">1 - <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?> is equal to <?php echo e(substr($dm->email,0,strpos($dm->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;<?php echo e($dm->id); ?>;2">2 - <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?> is 2x most important than <?php echo e(substr($dm->email,0,strpos($dm->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;<?php echo e($dm->id); ?>;3">3 - <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?> is 3x most important than <?php echo e(substr($dm->email,0,strpos($dm->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;<?php echo e($dm->id); ?>;4">4 - <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?> is 4x most important than <?php echo e(substr($dm->email,0,strpos($dm->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;<?php echo e($dm->id); ?>;5">5 - <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?> is 5x most important than <?php echo e(substr($dm->email,0,strpos($dm->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;<?php echo e($dm->id); ?>;6">6 - <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?> is 6x most important than <?php echo e(substr($dm->email,0,strpos($dm->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;<?php echo e($dm->id); ?>;7">7 - <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?> is 7x most important than <?php echo e(substr($dm->email,0,strpos($dm->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;<?php echo e($dm->id); ?>;8">8 - <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?> is 8x most important than <?php echo e(substr($dm->email,0,strpos($dm->email, '@') )); ?></option>
                        <option value="<?php echo e($goal->id); ?>;<?php echo e($proxy->id); ?>;<?php echo e($dm->id); ?>;9">9 - <?php echo e(substr($proxy->email,0,strpos($proxy->email, '@') )); ?> is 9x most important than <?php echo e(substr($dm->email,0,strpos($dm->email, '@') )); ?></option>
                    </select>
                </td>
            </tr>
            <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="btn-group">
        <button type="submit" class="btn btn-primary">Save</button>
        <a class="btn btn-danger" href="/nodes">Cancel</a>
    </div>
    <input type="hidden" name="counter" value="<?php echo e($i); ?>">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/objetivos/dmcomparisons.blade.php ENDPATH**/ ?>