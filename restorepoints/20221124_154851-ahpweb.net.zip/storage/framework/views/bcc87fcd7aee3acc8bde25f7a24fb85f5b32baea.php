<?php $__env->startSection('menu'); ?>

<ul class="navbar-nav mr-auto">

    <?php if(auth()->guard()->guest()): ?>
    <?php if(Route::has('login')): ?>
    <?php endif; ?>

    <?php if(Route::has('register')): ?>
    <?php endif; ?>
    <?php else: ?>

    <li class="nav-item">
        <form method="GET" action="/nodes">
            <?php echo csrf_field(); ?>
            <button style="border:none;background-color:transparent" type="submit" class="nav-link">My Decision Problems</button>
        </form>
    </li>
    &nbsp;&nbsp;&nbsp;&nbsp;
    <li>
        <form method="POST" action="/formCreateNode/0">
            <?php echo csrf_field(); ?>
            <button style="border:none;background-color:transparent" type="submit" class="nav-link">New Decision Problem</button>
        </form>
    </li>
    <?php endif; ?>

</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<ul class="nav nav-tabs">
    <li class="nav-item">
        <a class="nav-link " href="report">My results</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="groupreport">Group results</a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="HumanReport">Numerical results</a>
    </li>

</ul>
<div class="card">
    <div class="card-body">
        <h5 class="card-title">Criteria</h5>
        <table class="table">
            <thead class="thead-light">
                <tr align="center">
                    <th>Criteria</th>
                    <?php $__currentLoopData = $results->getCriteria(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <th scope="col">
                        <h6 style="color: red"><b><?php echo e($q["descr"]); ?></b></h6>
                    </th>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th scope="col">
                        <h6 style="color: black"><b>Priority Vector</b></h6>
                    </th>

                </tr>
            </thead>
            <tbody>
                <!--<?php echo e($i=-1); ?>

            foreach ($j_criteria as $c) {
            foreach ($c as $score) {
                printf("%.2f&nbsp;&nbsp;&nbsp;&nbsp;", $score);
            }
            echo "<br>";
        }
-->


                <?php $__currentLoopData = $j_criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr align="center">
                    <td scope="col">
                        <h6 style="color: blue"><b><?php echo e($results->getCriteria()[++$i]["descr"]); ?></b></h6>
                    </td>
                    <!-- <?php echo e($j = -1); ?> -->
                    <?php $__currentLoopData = $c; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($jc < 1): ?> <td scope="col"><a data-toggle="modal" data-target="#excluir_<?php echo e($i); ?>_<?php echo e($j+1); ?>" href="" style="color: red" title="<?php echo e($results->getCriteria()[++$j]['descr']); ?> is <?php echo e(round(pow($jc,-1),0)); ?>x most important/relevant than <?php echo e($results->getCriteria()[$i]['descr']); ?>"><b>1/<?php echo e(round(pow($jc,-1),0)); ?></b></a></td>
                        <?php elseif($jc > 1): ?>
                        <td scope="col">
                            <a data-toggle="modal" data-target="#excluir_<?php echo e($i); ?>_<?php echo e($j+1); ?>" href="" style="color: blue" title="<?php echo e($results->getCriteria()[$i]['descr']); ?> is <?php echo e(round($jc,3)); ?>x most important/relevant than <?php echo e($results->getCriteria()[++$j]['descr']); ?>"><b><?php echo e(round($jc,3)); ?></b></a>
                        </td>
                        <?php else: ?>
                        <td scope="col">
                            <a href="" style="color: black" title="<?php echo e($results->getCriteria()[++$j]['descr']); ?> is indifferent than <?php echo e($results->getCriteria()[$i]['descr']); ?>"><b><?php echo e(round($jc,3)); ?></b></a>
                        </td>
                        <?php endif; ?>
                        <div class="modal" id="excluir_<?php echo e($i); ?>_<?php echo e($j); ?>">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Update Judment</h4>
                                        <!--<button type="button" class="close" data-dismiss="modal"></button>-->
                                    </div>
                                    <div class="modal-body">
                                        Update comparison between:
                                        <strong><?php echo e($results->getCriteria()[$i]['descr']); ?> X <?php echo e($results->getCriteria()[$j]['descr']); ?></strong>
                                        <br><span id="show<?php echo e($i); ?><?php echo e($j); ?>"></span>
                                    </div>
                                    <form method="POST" action="/UpdateSingleScore">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="newjudment" value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getNodeId()[$i]['id']); ?>;<?php echo e($results->getNodeId()[$j]['id']); ?>">
                                <div align="center" class="slidecontainer">
                                    <input type="range" min="-9" max="9" value="0" step="1" class="slider" name="newscore" id="newjudment<?php echo e($i); ?><?php echo e($j); ?>">
                                </div> 
                                <script type="text/javascript">
                                    var slider<?php echo e($i); ?><?php echo e($j); ?> = document.getElementById("newjudment<?php echo e($i); ?><?php echo e($j); ?>");
                                    var output<?php echo e($i); ?><?php echo e($j); ?> = document.getElementById("show<?php echo e($i); ?><?php echo e($j); ?>");
                                    output<?php echo e($i); ?><?php echo e($j); ?>.innerHTML = '<span style="color: #00f;font-style: italic;"><?php echo e($results->getCriteria()[$i]['descr']); ?></span> is indifferent to <span style="color: #f00;font-style: italic;"><?php echo e($results->getCriteria()[$j]['descr']); ?></span>';

                                    slider<?php echo e($i); ?><?php echo e($j); ?>.oninput = function() {
                                        if(this.value < -1)
                                            output<?php echo e($i); ?><?php echo e($j); ?>.innerHTML = '<span style="color: #00f;font-style: italic;"><?php echo e($results->getCriteria()[$i]['descr']); ?></span> is ' + this.value * (-1) + 'x preferable than <span style="color: #f00;font-style: italic;"><?php echo e($results->getCriteria()[$j]['descr']); ?></span>';
                                        else if (this.value > 1)
                                            output<?php echo e($i); ?><?php echo e($j); ?>.innerHTML = '<span style="color: #f00;font-style: italic;"><?php echo e($results->getCriteria()[$j]['descr']); ?></span> is ' + this.value + 'x preferable than <span style="color: #00f;font-style: italic;"><?php echo e($results->getCriteria()[$i]['descr']); ?></span>';
                                            else if (this.value == -1 || this.value == 0 || this.value == 1)
                                            output<?php echo e($i); ?><?php echo e($j); ?>.innerHTML = '<span style="color: #00f;font-style: italic;"><?php echo e($results->getCriteria()[$i]['descr']); ?></span> is indifferent to <span style="color: #f00;font-style: italic;"><?php echo e($results->getCriteria()[$j]['descr']); ?></span>';
                                    }
                                </script>
                                        <!--
                                        <select id="newjudment" name="newjudment">
                                            <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getNodeId()[$i]['id']); ?>;<?php echo e($results->getNodeId()[$j]['id']); ?>;<?php echo e(9); ?>">1/9 <?php echo e($results->getCriteria()[$j]['descr']); ?> is 9x preferable than <?php echo e($results->getCriteria()[$i]['descr']); ?></option>
                                            <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getNodeId()[$i]['id']); ?>;<?php echo e($results->getNodeId()[$j]['id']); ?>;<?php echo e(8); ?>">1/8 <?php echo e($results->getCriteria()[$j]['descr']); ?> is 8x preferable than <?php echo e($results->getCriteria()[$i]['descr']); ?></option>
                                            <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getNodeId()[$i]['id']); ?>;<?php echo e($results->getNodeId()[$j]['id']); ?>;<?php echo e(7); ?>">1/7 <?php echo e($results->getCriteria()[$j]['descr']); ?> is 7x preferable than <?php echo e($results->getCriteria()[$i]['descr']); ?></option>
                                            <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getNodeId()[$i]['id']); ?>;<?php echo e($results->getNodeId()[$j]['id']); ?>;<?php echo e(6); ?>">1/6 <?php echo e($results->getCriteria()[$j]['descr']); ?> is 6x preferable than <?php echo e($results->getCriteria()[$i]['descr']); ?></option>
                                            <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getNodeId()[$i]['id']); ?>;<?php echo e($results->getNodeId()[$j]['id']); ?>;<?php echo e(5); ?>">1/5 <?php echo e($results->getCriteria()[$j]['descr']); ?> is 5x preferable than <?php echo e($results->getCriteria()[$i]['descr']); ?></option>
                                            <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getNodeId()[$i]['id']); ?>;<?php echo e($results->getNodeId()[$j]['id']); ?>;<?php echo e(4); ?>">1/4 <?php echo e($results->getCriteria()[$j]['descr']); ?> is 4x preferable than <?php echo e($results->getCriteria()[$i]['descr']); ?></option>
                                            <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getNodeId()[$i]['id']); ?>;<?php echo e($results->getNodeId()[$j]['id']); ?>;<?php echo e(3); ?>">1/3 <?php echo e($results->getCriteria()[$j]['descr']); ?> is 3x preferable than <?php echo e($results->getCriteria()[$i]['descr']); ?></option>
                                            <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getNodeId()[$i]['id']); ?>;<?php echo e($results->getNodeId()[$j]['id']); ?>;<?php echo e(2); ?>">1/2 <?php echo e($results->getCriteria()[$j]['descr']); ?> is 2x preferable than <?php echo e($results->getCriteria()[$i]['descr']); ?></option>
                                            <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getNodeId()[$i]['id']); ?>;<?php echo e($results->getNodeId()[$j]['id']); ?>;<?php echo e(1); ?>">1 <?php echo e($results->getCriteria()[$i]['descr']); ?> is indifferent than <?php echo e($results->getCriteria()[$j]['descr']); ?></option>
                                            <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getNodeId()[$i]['id']); ?>;<?php echo e($results->getNodeId()[$j]['id']); ?>;<?php echo e(1/2); ?>">2 <?php echo e($results->getCriteria()[$i]['descr']); ?> is 2x preferable than <?php echo e($results->getCriteria()[$j]['descr']); ?></option>
                                            <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getNodeId()[$i]['id']); ?>;<?php echo e($results->getNodeId()[$j]['id']); ?>;<?php echo e(1/3); ?>">3 <?php echo e($results->getCriteria()[$i]['descr']); ?> is 3x preferable than <?php echo e($results->getCriteria()[$j]['descr']); ?></option>
                                            <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getNodeId()[$i]['id']); ?>;<?php echo e($results->getNodeId()[$j]['id']); ?>;<?php echo e(1/4); ?>">4 <?php echo e($results->getCriteria()[$i]['descr']); ?> is 4x preferable than <?php echo e($results->getCriteria()[$j]['descr']); ?></option>
                                            <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getNodeId()[$i]['id']); ?>;<?php echo e($results->getNodeId()[$j]['id']); ?>;<?php echo e(1/5); ?>">5 <?php echo e($results->getCriteria()[$i]['descr']); ?> is 5x preferable than <?php echo e($results->getCriteria()[$j]['descr']); ?></option>
                                            <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getNodeId()[$i]['id']); ?>;<?php echo e($results->getNodeId()[$j]['id']); ?>;<?php echo e(1/6); ?>">6 <?php echo e($results->getCriteria()[$i]['descr']); ?> is 6x preferable than <?php echo e($results->getCriteria()[$j]['descr']); ?></option>
                                            <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getNodeId()[$i]['id']); ?>;<?php echo e($results->getNodeId()[$j]['id']); ?>;<?php echo e(1/7); ?>">7 <?php echo e($results->getCriteria()[$i]['descr']); ?> is 7x preferable than <?php echo e($results->getCriteria()[$j]['descr']); ?></option>
                                            <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getNodeId()[$i]['id']); ?>;<?php echo e($results->getNodeId()[$j]['id']); ?>;<?php echo e(1/8); ?>">8 <?php echo e($results->getCriteria()[$i]['descr']); ?> is 8x preferable than <?php echo e($results->getCriteria()[$j]['descr']); ?></option>
                                            <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getNodeId()[$i]['id']); ?>;<?php echo e($results->getNodeId()[$j]['id']); ?>;<?php echo e(1/9); ?>">9 <?php echo e($results->getCriteria()[$i]['descr']); ?> is 9x preferable than <?php echo e($results->getCriteria()[$j]['descr']); ?></option>
                                        </select>
    -->
                                        <div class="modal-footer">
                                            <div class="btn-group">
                                                <button type="submit" class="btn btn-primary">Save</button>
                                                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                                                <!--<a class="btn btn-danger" href="#">Remove</a>-->
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td scope="col">
                            <h6 style="color: black"><b><?php echo e(round($results->getPriority()[$i],3)); ?></b></h6>
                        </td>
                </tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div align="center"><?php
                            $j_criteria = App\Http\Controllers\AHPController::GetCriteriaJudmentsMatrix($results->getObjectiveId(), 0, null);
                            $consistency_rate = App\Http\Controllers\AHPController::CheckConsistency($j_criteria);
                            $ci = App\Http\Controllers\AHPController::GetConsistencyIndex($j_criteria);
                            $lambda = App\Http\Controllers\AHPController::GetLambdaMax($j_criteria);
                            ?><i>
                &lambda; max: <?php echo e(round($lambda,3)); ?>, Consistency Index: <?php echo e(round($ci,3)); ?>, Consistency Rate: <?php echo e(round( ($consistency_rate), 3 )); ?> (<?php echo e(round( ($consistency_rate)*100 , 3 )); ?>%)
            </i>
        </div>

    </div>
</div>
<br><br>
<div class="card">
    <div class="card-body">
        <h5 class="card-title">Alternatives</h5>
    </div>
</div>
<table class="table">
    <tbody>
        <!-- <?php echo e($i=-1); ?>

    <?php echo e($j=-1); ?> -->
        <?php $__currentLoopData = $j_alternatives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr align="center">
            <th>
                <h6 id="<?php echo e($results->getCriteria()[$j+1]['id']); ?>">
                    <?php echo e($results->getCriteria()[++$j]['descr']); ?>

                    <?php
                    $c_alternatives = App\Http\Controllers\AHPController::GetCriteriaJudmentsMatrix($results->getCriteria()[$j]['id'], 0, null);
                    $a_priority = App\Http\Controllers\AHPController::GetPriority($c_alternatives);
                    ?>
                </h6>
            </th>
            <?php $__currentLoopData = $results->getAlternatives(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th>
                <h6 style="color: red"><b><?php echo e($x["descr"]); ?></b></h6>
            </th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <th>
                <h6 style="color: black"><b>Priority Vector</b></h6>
            </th>
        </tr>
        <?php $__currentLoopData = $a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr align="center">
            <td>
                <h6 style="color: blue"><b><?php echo e($results->getAlternatives()[++$i]["descr"]); ?></b></h6>
            </td>
            <!-- <?php echo e($k = -1); ?> -->
            <?php $__currentLoopData = $b; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($c < 1): ?> <td>
                <a data-toggle="modal" data-target="#change_<?php echo e($j); ?>_<?php echo e($i); ?>_<?php echo e($k+1); ?>" href="" style="color: red" title="In <?php echo e($results->getCriteria()[$j]['descr']); ?> <?php echo e($results->getAlternatives()[++$k]['descr']); ?> is <?php echo e(round(pow($c,-1),0)); ?>x most important/relevant than <?php echo e($results->getAlternatives()[$i]['descr']); ?>">
                    <b>
                        <!--<?php echo e($aa = $i); ?>-->
                        1/<?php echo e(round(pow($c,-1),0)); ?>

                    </b>
                </a>
                </td>
                <?php elseif($c > 1): ?>
                <td>
                    <a data-toggle="modal" data-target="#change_<?php echo e($j); ?>_<?php echo e($i); ?>_<?php echo e($k+1); ?>" href="" style="color: blue" title="In <?php echo e($results->getCriteria()[$j]['descr']); ?> <?php echo e($results->getAlternatives()[$i]['descr']); ?> is <?php echo e(round($c,2)); ?>x most important/relevant than <?php echo e($results->getAlternatives()[++$k]['descr']); ?>">
                        <b>
                            <?php echo e(round($c,2)); ?>

                        </b>
                    </a>
                </td>
                <?php else: ?>
                <td>
                    <h6 style="color: black">
                        <b>
                            <?php echo e(round($c,2)); ?>

                        </b>
                    </h6><!-- <?php echo e(++$k); ?> -->
                </td>
                <?php endif; ?>

                <!--modal here-->
                <div class="modal" id="change_<?php echo e($j); ?>_<?php echo e($i); ?>_<?php echo e($k); ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title">Update Judment</h4>
                                <!--<button type="button" class="close" data-dismiss="modal"></button>-->
                            </div>
                            <div class="modal-body">
                                Update comparison in <i><?php echo e($results->getCriteria()[$j]['descr']); ?></i> between:
                                <strong><?php echo e($results->getAlternatives()[$i]['descr']); ?> X <?php echo e($results->getAlternatives()[$k]['descr']); ?></strong>
                                <br><span id="show<?php echo e($j); ?><?php echo e($i); ?><?php echo e($k); ?>"></span>
                            </div>
                            <form method="POST" action="/UpdateSingleScore">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="newjudment" value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getCriteria()[$j]['id']); ?>;<?php echo e($results->getAlternatives()[$i]['id']); ?>;<?php echo e($results->getAlternatives()[$k]['id']); ?>">
                                <div align="center" class="slidecontainer">
                                    <input type="range" min="-9" max="9" value="0" step="1" class="slider" name="newscore" id="newjudment<?php echo e($j); ?><?php echo e($i); ?><?php echo e($k); ?>">
                                </div> 
                                <script type="text/javascript">
                                    var slider<?php echo e($j); ?><?php echo e($i); ?><?php echo e($k); ?> = document.getElementById("newjudment<?php echo e($j); ?><?php echo e($i); ?><?php echo e($k); ?>");
                                    var output<?php echo e($j); ?><?php echo e($i); ?><?php echo e($k); ?> = document.getElementById("show<?php echo e($j); ?><?php echo e($i); ?><?php echo e($k); ?>");
                                    output<?php echo e($j); ?><?php echo e($i); ?><?php echo e($k); ?>.innerHTML = '<span style="color: #00f;font-style: italic;"><?php echo e($results->getAlternatives()[$i]['descr']); ?></span> is indifferent to <span style="color: #f00;font-style: italic;"><?php echo e($results->getAlternatives()[$k]['descr']); ?></span>';

                                    slider<?php echo e($j); ?><?php echo e($i); ?><?php echo e($k); ?>.oninput = function() {
                                        if(this.value > 1)
                                            output<?php echo e($j); ?><?php echo e($i); ?><?php echo e($k); ?>.innerHTML = '<span style="color: #f00;font-style: italic;"><?php echo e($results->getAlternatives()[$k]['descr']); ?></span> is ' + this.value + 'x preferable than <span style="color: #00f;font-style: italic;"><?php echo e($results->getAlternatives()[$i]['descr']); ?></span>';
                                        else if (this.value < -1)
                                            output<?php echo e($j); ?><?php echo e($i); ?><?php echo e($k); ?>.innerHTML = '<span style="color: #00f;font-style: italic;"><?php echo e($results->getAlternatives()[$i]['descr']); ?></span> is ' + this.value * (-1) + 'x preferable than <span style="color: #f00;font-style: italic;"><?php echo e($results->getAlternatives()[$k]['descr']); ?></span>';
                                        else if (this.value == -1 || this.value == 0 || this.value == 1)
                                            output<?php echo e($j); ?><?php echo e($i); ?><?php echo e($k); ?>.innerHTML = '<span style="color: #00f;font-style: italic;"><?php echo e($results->getAlternatives()[$i]['descr']); ?></span> is indifferent to <span style="color: #f00;font-style: italic;"><?php echo e($results->getAlternatives()[$k]['descr']); ?></span>';
                                    }
                                </script>
                                <!-- 
                                <select id="newjudment" name="newjudment">
                                    <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getCriteria()[$j]['id']); ?>;<?php echo e($results->getAlternatives()[$i]['id']); ?>;<?php echo e($results->getAlternatives()[$k]['id']); ?>;<?php echo e(9); ?>">1/9 <?php echo e($results->getAlternatives()[$k]['descr']); ?> is 9x preferable than <?php echo e($results->getAlternatives()[$i]['descr']); ?></option>
                                    <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getCriteria()[$j]['id']); ?>;<?php echo e($results->getAlternatives()[$i]['id']); ?>;<?php echo e($results->getAlternatives()[$k]['id']); ?>;<?php echo e(8); ?>">1/8 <?php echo e($results->getAlternatives()[$k]['descr']); ?> is 8x preferable than <?php echo e($results->getAlternatives()[$i]['descr']); ?></option>
                                    <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getCriteria()[$j]['id']); ?>;<?php echo e($results->getAlternatives()[$i]['id']); ?>;<?php echo e($results->getAlternatives()[$k]['id']); ?>;<?php echo e(7); ?>">1/7 <?php echo e($results->getAlternatives()[$k]['descr']); ?> is 7x preferable than <?php echo e($results->getAlternatives()[$i]['descr']); ?></option>
                                    <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getCriteria()[$j]['id']); ?>;<?php echo e($results->getAlternatives()[$i]['id']); ?>;<?php echo e($results->getAlternatives()[$k]['id']); ?>;<?php echo e(6); ?>">1/6 <?php echo e($results->getAlternatives()[$k]['descr']); ?> is 6x preferable than <?php echo e($results->getAlternatives()[$i]['descr']); ?></option>
                                    <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getCriteria()[$j]['id']); ?>;<?php echo e($results->getAlternatives()[$i]['id']); ?>;<?php echo e($results->getAlternatives()[$k]['id']); ?>;<?php echo e(5); ?>">1/5 <?php echo e($results->getAlternatives()[$k]['descr']); ?> is 5x preferable than <?php echo e($results->getAlternatives()[$i]['descr']); ?></option>
                                    <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getCriteria()[$j]['id']); ?>;<?php echo e($results->getAlternatives()[$i]['id']); ?>;<?php echo e($results->getAlternatives()[$k]['id']); ?>;<?php echo e(4); ?>">1/4 <?php echo e($results->getAlternatives()[$k]['descr']); ?> is 4x preferable than <?php echo e($results->getAlternatives()[$i]['descr']); ?></option>
                                    <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getCriteria()[$j]['id']); ?>;<?php echo e($results->getAlternatives()[$i]['id']); ?>;<?php echo e($results->getAlternatives()[$k]['id']); ?>;<?php echo e(3); ?>">1/3 <?php echo e($results->getAlternatives()[$k]['descr']); ?> is 3x preferable than <?php echo e($results->getAlternatives()[$i]['descr']); ?></option>
                                    <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getCriteria()[$j]['id']); ?>;<?php echo e($results->getAlternatives()[$i]['id']); ?>;<?php echo e($results->getAlternatives()[$k]['id']); ?>;<?php echo e(2); ?>">1/2 <?php echo e($results->getAlternatives()[$k]['descr']); ?> is 2x preferable than <?php echo e($results->getAlternatives()[$i]['descr']); ?></option>
                                    <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getCriteria()[$j]['id']); ?>;<?php echo e($results->getAlternatives()[$i]['id']); ?>;<?php echo e($results->getAlternatives()[$k]['id']); ?>;<?php echo e(1); ?>">1 <?php echo e($results->getAlternatives()[$k]['descr']); ?> is indifferent than <?php echo e($results->getAlternatives()[$i]['descr']); ?></option>
                                    <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getCriteria()[$j]['id']); ?>;<?php echo e($results->getAlternatives()[$i]['id']); ?>;<?php echo e($results->getAlternatives()[$k]['id']); ?>;<?php echo e(1/2); ?>">2 <?php echo e($results->getAlternatives()[$i]['descr']); ?> is 2x preferable than <?php echo e($results->getAlternatives()[$k]['descr']); ?></option>
                                    <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getCriteria()[$j]['id']); ?>;<?php echo e($results->getAlternatives()[$i]['id']); ?>;<?php echo e($results->getAlternatives()[$k]['id']); ?>;<?php echo e(1/3); ?>">3 <?php echo e($results->getAlternatives()[$i]['descr']); ?> is 3x preferable than <?php echo e($results->getAlternatives()[$k]['descr']); ?></option>
                                    <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getCriteria()[$j]['id']); ?>;<?php echo e($results->getAlternatives()[$i]['id']); ?>;<?php echo e($results->getAlternatives()[$k]['id']); ?>;<?php echo e(1/4); ?>">4 <?php echo e($results->getAlternatives()[$i]['descr']); ?> is 4x preferable than <?php echo e($results->getAlternatives()[$k]['descr']); ?></option>
                                    <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getCriteria()[$j]['id']); ?>;<?php echo e($results->getAlternatives()[$i]['id']); ?>;<?php echo e($results->getAlternatives()[$k]['id']); ?>;<?php echo e(1/5); ?>">5 <?php echo e($results->getAlternatives()[$i]['descr']); ?> is 5x preferable than <?php echo e($results->getAlternatives()[$k]['descr']); ?></option>
                                    <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getCriteria()[$j]['id']); ?>;<?php echo e($results->getAlternatives()[$i]['id']); ?>;<?php echo e($results->getAlternatives()[$k]['id']); ?>;<?php echo e(1/6); ?>">6 <?php echo e($results->getAlternatives()[$i]['descr']); ?> is 6x preferable than <?php echo e($results->getAlternatives()[$k]['descr']); ?></option>
                                    <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getCriteria()[$j]['id']); ?>;<?php echo e($results->getAlternatives()[$i]['id']); ?>;<?php echo e($results->getAlternatives()[$k]['id']); ?>;<?php echo e(1/7); ?>">7 <?php echo e($results->getAlternatives()[$i]['descr']); ?> is 7x preferable than <?php echo e($results->getAlternatives()[$k]['descr']); ?></option>
                                    <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getCriteria()[$j]['id']); ?>;<?php echo e($results->getAlternatives()[$i]['id']); ?>;<?php echo e($results->getAlternatives()[$k]['id']); ?>;<?php echo e(1/8); ?>">8 <?php echo e($results->getAlternatives()[$i]['descr']); ?> is 8x preferable than <?php echo e($results->getAlternatives()[$k]['descr']); ?></option>
                                    <option value="<?php echo e($results->getObjectiveId()); ?>;<?php echo e($results->getCriteria()[$j]['id']); ?>;<?php echo e($results->getAlternatives()[$i]['id']); ?>;<?php echo e($results->getAlternatives()[$k]['id']); ?>;<?php echo e(1/9); ?>">9 <?php echo e($results->getAlternatives()[$i]['descr']); ?> is 9x preferable than <?php echo e($results->getAlternatives()[$k]['descr']); ?></option>
                                </select>
    -->
                                <div class="modal-footer">
                                    <div class="btn-group">
                                        <button type="submit" class="btn btn-primary">Save</button>
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                                        <!--<a class="btn btn-danger" href="#">Remove</a>-->
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- end modal -->



                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <td scope="col">
                    <h6 style="color: black"><b><?php echo e(round($a_priority[$i],3)); ?></b></h6>
                </td>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- <?php echo e($i=-1); ?> -->
        <tr>
            <td align="center" colspan="<?php echo e($k+3); ?>">
                <?php
                $j_criteria = App\Http\Controllers\AHPController::GetCriteriaJudmentsMatrix($results->getNodeId()[$j]['id'], 0, null);
                $consistency_rate = App\Http\Controllers\AHPController::CheckConsistency($j_criteria);
                $ci = App\Http\Controllers\AHPController::GetConsistencyIndex($j_criteria);
                $lambda = App\Http\Controllers\AHPController::GetLambdaMax($j_criteria);
                ?>
                <i>
                    &lambda; max: <?php echo e(round($lambda,3)); ?>, Consistency Index: <?php echo e(round($ci,3)); ?>, Consistency Rate: <?php echo e(round( ($consistency_rate), 3 )); ?> (<?php echo e(round( ($consistency_rate)*100 , 3 )); ?>%)
                </i>
                <hr color="black">
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    </tbody>
</table>

<hr color="FFOOOO">

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/objetivos/humanReport.blade.php ENDPATH**/ ?>