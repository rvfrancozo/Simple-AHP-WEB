<?php $__env->startSection('menu'); ?>

<ul class="navbar-nav mr-auto">

	<?php if(auth()->guard()->guest()): ?>
	<?php if(Route::has('login')): ?>
	<?php endif; ?>

	<?php if(Route::has('register')): ?>
	<?php endif; ?>
	<?php else: ?>

	<li class="nav-item">
		<form method="GET" action="/nodes">
			<?php echo csrf_field(); ?>
			<button style="border:none;background-color:transparent" type="submit" class="nav-link">My Decision Problems</button>
		</form>
	</li>
	&nbsp;&nbsp;&nbsp;&nbsp;
	<li>
		<form method="POST" action="/formCreateNode/0">
			<?php echo csrf_field(); ?>
			<button style="border:none;background-color:transparent" type="submit" class="nav-link">New Decision Problem</button>
		</form>
	</li>
	<?php endif; ?>

</ul>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('conteudo'); ?>
 
<ul class="nav nav-tabs">
<li class="nav-item">
        <a class="nav-link " href="report">My results</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="groupreport">Group results</a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="HumanReport">Numerical results</a>
    </li>
  
</ul>

<div class="container">

	<h3> <class="lead"> Objective: <?php echo e($results->getObjective()); ?> </h3>
	
</div>

<!-- 
    <h5 class="card-title">Criterios</h5>

   <?php $__currentLoopData = $results->getCriteria(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	<div class="card-body">
    
    <p class="card-text"><?php echo e($q['descr']); ?></p>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <h5 class="card-title">Alternativas</h5>

    <?php $__currentLoopData = $results->getAlternatives(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 <div class="card-body">
 
 <p class="card-text"><?php echo e($a['descr']); ?></p>
 </div>

 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 <h5 class="card-title">Score</h5>

<?php $__currentLoopData = $results->getScore(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="card-body">

<p class="card-text"><?php echo e($s); ?></p>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
-->

<!-- <?php for($i = 0; $i < count($results->getAlternatives()) ; $i++): ?>
    <?php echo e($results->getAlternatives()[$i]->descr); ?>: <?php echo e($results->getScore()[$i]); ?> <br>
<?php endfor; ?> -->


	

<hr>
The most relevant Alternative for the decision problem <?php echo e($results->getObjective()); ?> is:<b> <?php echo e($results->getBestAlternative()); ?></b> with <?php echo e(round($results->getBestAlternativeScore()*100,2)); ?>% of priority.
<hr>

<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="chart-wrapper">
				<canvas id="myChart2"></canvas>
			</div>
		</div>
	</div>
</div>

<hr>
The -- most relevant Criterion for the decision problem <?php echo e($results->getObjective()); ?> is: <b><?php echo e($results->getBestCriteria()); ?> </b> with <?php echo e(round($results->getBestCriteriaPriority()*100,2)); ?>% of priority.
	
<hr>	
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="chart-wrapper">
				<canvas id="myChart"></canvas>
			</div>
		</div>
	</div>
</div> 
<!--
	os dois scripts abaixo são necessários para colocar os labels nos gráficos 
	é necessário instalar o plugin também
	npm install chartjs-plugin-datalabels --save
 -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@3.0.0/dist/chart.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0"></script>

	<script>

		//Data dos Critérios
			const data = {
				labels: [
					<?php $__currentLoopData = $results->getCriteria(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					'<?php echo e($a['descr']); ?>',
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					],
				datasets: [{
					label: '% of priority of alternatives for the objective: <?php echo e($results->getObjective()); ?>',
					data: [
						<?php $__currentLoopData = $results->getPriority(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php echo e(round($s*100,2)); ?>,
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					],
					backgroundColor: [
						'rgba(255, 99, 132, 0.2)',
						'rgba(54, 162, 235, 0.2)',
						'rgba(255, 206, 86, 0.2)',
						'rgba(75, 192, 192, 0.2)',
						'rgba(153, 102, 255, 0.2)',
						'rgba(255, 159, 64, 0.2)'
					],
					borderColor: [
						'rgba(255, 99, 132, 1)',
						'rgba(54, 162, 235, 1)',
						'rgba(255, 206, 86, 1)',
						'rgba(75, 192, 192, 1)',
						'rgba(153, 102, 255, 1)',
						'rgba(255, 159, 64, 1)'
					],
					borderWidth: 1,
					datalabels: { //formatação do label
						color: 'black',
						anchor: 'end',
						align: 'top',
						offset: 0
					}
				}]
			};
			
			//Configurações Gráfico 1
			const config = {
				type: 'bar',
				data,
				plugins: [ChartDataLabels], //plugin dos labels
				options: {
					//configuração do label
					plugins: {
						datalabels: {
							formatter: function(value, context) {
								//return context.chart.data.labels[context.dataIndex];
								//return context.dataIndex + ': ' + Math.round(value*100) + '%';
								//return context.dataIndex + ': ' + Math.round(value*100) + '%';
								return value + '%';
								}
								}
							},

					scales: {
						y:{
							beginAtZero: true,
							grid: {
								borderColor: 'black',
								borderWidth: 1,
								display: false
							}
						},
						x:{
							grid: {
								borderColor: 'black',
								borderWidth: 1,
								display: false
							}
						}
					}
				}
			};

			//Renderiza o Gráfico 1
			const MyChart = new Chart( 
			document.getElementById('myChart'),
			config
			);
						

			//Data das Alternativas
			const data2 = {
				labels: [
					<?php $__currentLoopData = $results->getAlternatives(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					'<?php echo e($a['descr']); ?>',
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					],
				datasets: [{
					label: '% of priority of alternatives for the objective: <?php echo e($results->getObjective()); ?>',
					data: [
						<?php $__currentLoopData = $results->getScore(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						'<?php echo e(round($s*100,2)); ?>',
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					],
					backgroundColor: [
						'rgba(255, 99, 132, 0.2)',
						'rgba(54, 162, 235, 0.2)',
						'rgba(255, 206, 86, 0.2)',
						'rgba(75, 192, 192, 0.2)',
						'rgba(153, 102, 255, 0.2)',
						'rgba(255, 159, 64, 0.2)'
					],
					borderColor: [
						'rgba(255, 99, 132, 1)',
						'rgba(54, 162, 235, 1)',
						'rgba(255, 206, 86, 1)',
						'rgba(75, 192, 192, 1)',
						'rgba(153, 102, 255, 1)',
						'rgba(255, 159, 64, 1)'
					],
					borderWidth: 1,
					datalabels: { //formatação do label
						color: 'black',
						anchor: 'end',
						align: 'top',
						offset: 0
					}
					
				}]
			};

			//Configurações Gráfico 2
			const config2 = {
				type: 'bar',
				
				data: data2,
				plugins: [ChartDataLabels], //plugin dos labels
				options: {
					//configuração do label
					plugins: {
						datalabels: {
							formatter: function(value, context) {
								//return context.chart.data.labels[context.dataIndex];
								//return context.dataIndex + ': ' + Math.round(value*100) + '%';
								//return context.dataIndex + ': ' + Math.round(value*100) + '%';
								return value + '%';
								}
								}
							},
					scales: {
						y:{
							beginAtZero: true,
							grid: {
								borderColor: 'black',
								borderWidth: 1,
								display: false
							}
						},
						x:{
							grid: {
								borderColor: 'black',
								borderWidth: 1,
								display: false
							}
						}
					}
				}
			};
			
			////Renderiza o Gráfico 1
			const MyChart2 = new Chart( 
			document.getElementById('myChart2'),
			config2
			);
		
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/objetivos/report.blade.php ENDPATH**/ ?>