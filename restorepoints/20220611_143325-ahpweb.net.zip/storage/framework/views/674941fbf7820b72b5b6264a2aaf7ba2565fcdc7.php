<?php $__env->startSection('menu'); ?>

<ul class="navbar-nav mr-auto">

	<?php if(auth()->guard()->guest()): ?>
	<?php if(Route::has('login')): ?>
	<?php endif; ?>

	<?php if(Route::has('register')): ?>
	<?php endif; ?>
	<?php else: ?>

	<li class="nav-item">
		<form method="GET" action="/nodes">
			<?php echo csrf_field(); ?>
			<button style="border:none;background-color:transparent" type="submit" class="nav-link">My Decision Problems</button>
		</form>
	</li>
	&nbsp;&nbsp;&nbsp;&nbsp;
	<li>
		<form method="POST" action="/formCreateNode/0">
			<?php echo csrf_field(); ?>
			<button style="border:none;background-color:transparent" type="submit" class="nav-link">New Decision Problem</button>
		</form>
	</li>
	<?php endif; ?>

</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<!-- <?php echo e($x = 0); ?>  -->
<?php if(isset($error)): ?>
<div class="alert-danger"> Criteria and alternatives are required to show the report. </div>
<?php endif; ?>
<div>
	<table class="table table-bordered table-striped table-hover">
		<thead>
			<tr>
				<th>#</th>
				<th>My Decision Problems</th>
				<th>View</th>
				<th>Operations</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $objectives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<tr>
				<td><?php echo e(++$x); ?></td>
				<td>
					<?php echo e($o['descr']); ?>

				</td>
				<td>
					<div class="btn-group">
						<a href="/nodes/<?php echo e($o['id']); ?>/criteria" class="btn btn-sm btn-primary" data-toggle="tooltip" title="">Criteria</a>
						&nbsp;<a href="/nodes/<?php echo e($o['id']); ?>/alternatives" class="btn btn-sm btn-primary" data-toggle="tooltip" title="teste">Alternatives</a>
					</div>
				</td>

				<td>
					<div class="btn-group">
						<a class="btn btn-primary btn-sm" href="/nodes/<?php echo e($o->id); ?>/report">Report <i class='fas fa-poll' style='font-size:12px;color:white'></i></a>
						&nbsp;<a class="btn btn-primary btn-sm" href="/group/<?php echo e($o->id); ?>/dm">Group <i class='fas fa-users' style='font-size:12px;color:white'></i> </a>
						&nbsp;<button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#excluir_<?php echo e($o->id); ?>" disabled>Remove</button>
					</div>
					<div class="modal" id="excluir_<?php echo e($o->id); ?>">
						<div class="modal-dialog">
							<div class="modal-content">
								<div class="modal-header">
									<h4 class="modal-title">Are you sure? #<?php echo e($o->id); ?></h4>
									<button type="button" class="close" data-dismiss="modal"></button>
								</div>
								<div class="modal-body">
									<strong>Decision Problem:</strong> <?php echo e($o->descr); ?>

								</div>
								<div class="modal-footer">
									<div class="btn-group">
										<button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
										<a class="btn btn-danger" href="/node/<?php echo e($o->id); ?>/remove">Remove</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</td>
			</tr>


			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</tbody>
	</table>

	<hr>

	<table class="table table-bordered table-striped table-hover">
		<thead>
			<tr>
				<th>#</th>
				<th>My Team Decision Problems</th>
				<th>Actions</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e(++$x); ?></td>
				<td>
					<?php echo e($o['descr']); ?>

				</td>
				<td>
					<div class="btn-group">
						<a href="/nodes/<?php echo e($o['id']); ?>/criteria" class="btn btn-sm btn-primary" data-toggle="tooltip" title="">Criteria</a>
						&nbsp;<a href="/nodes/<?php echo e($o['id']); ?>/alternatives" class="btn btn-sm btn-primary" data-toggle="tooltip" title="teste">Alternatives</a>
						&nbsp;<a class="btn btn-primary btn-sm" href="/nodes/<?php echo e($o->id); ?>/groupreport">Report <i class='fas fa-poll' style='font-size:12px;color:white'></i></a>
					</div>
				</td>
			</tr>


			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</tbody>
	</table>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/objetivos/nodes.blade.php ENDPATH**/ ?>