<?php $__env->startSection('menu'); ?>

<ul class="navbar-nav mr-auto">

	<?php if(auth()->guard()->guest()): ?>
	<?php if(Route::has('login')): ?>
	<?php endif; ?>

	<?php if(Route::has('register')): ?>
	<?php endif; ?>
	<?php else: ?>

	<li class="nav-item">
		<form method="GET" action="/nodes">
			<?php echo csrf_field(); ?>
			<button style="border:none;background-color:transparent" type="submit" class="nav-link">My Decision Problems</button>
		</form>
	</li>
	&nbsp;&nbsp;&nbsp;&nbsp;
	<li>
		<form method="POST" action="/formCreateNode/0">
			<?php echo csrf_field(); ?>
			<button style="border:none;background-color:transparent" type="submit" class="nav-link">New Decision Problem</button>
		</form>
	</li>
	<?php endif; ?>

</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('conteudo'); ?>
<div class="card">
  <div class="card-header">
    <h3>Create new <?php echo e($descr); ?></h3>
  </div>
  <div class="card-body">
    <form autocomplete="off" method="POST" action="/createNode/<?php echo e($up); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
        <?php for( $i = 0; $i < $nodes; $i++ ): ?>
        <label for="descricao">Name:</label>
        <input autocomplete="off" type="text" class="form-control" placeholder="" id="descricao" name="descricao[<?php echo e($i); ?>]">
        <?php endfor; ?>
        <input autocomplete="off" type=hidden name="level" value=<?php echo e($level); ?>>
      </div>
      <div class="btn-group">
        <button type="submit" class="btn btn-primary">Save</button>
        <a class="btn btn-danger" href="/nodes">Cancel</a>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/objetivos/formCreateNode.blade.php ENDPATH**/ ?>