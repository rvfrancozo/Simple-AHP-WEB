<?php $__env->startSection('menu'); ?>

<ul class="navbar-nav mr-auto">

    <?php if(auth()->guard()->guest()): ?>
    <?php if(Route::has('login')): ?>
    <?php endif; ?>

    <?php if(Route::has('register')): ?>
    <?php endif; ?>
    <?php else: ?>

    <li class="nav-item">
        <form method="GET" action="/nodes">
            <?php echo csrf_field(); ?>
            <button style="border:none;background-color:transparent" type="submit" class="nav-link">My Decision Problems</button>
        </form>
    </li>
    &nbsp;&nbsp;&nbsp;&nbsp;
    <li>
        <form method="POST" action="/formCreateNode/0">
            <?php echo csrf_field(); ?>
            <button style="border:none;background-color:transparent" type="submit" class="nav-link">New Decision Problem</button>
        </form>
    </li>
    <?php endif; ?>

</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('conteudo'); ?>
<div class="card">
    <div class="card-header">
        <h5>Add new decision-maker to Decision Problem: <?php echo e($descr); ?></h5>
    </div>
    <div class="card-body">
        <form autocomplete="off" method="POST" action="/createDM/<?php echo e($id); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="descricao">E-mail of new decision-maker:</label>
                <input autocomplete="off" type="text" class="form-control" placeholder="" id="descricao" name="descricao">
                <input autocomplete="off" type=hidden name="level" value="">
            </div>
            <div class="btn-group">
                <button type="submit" class="btn btn-primary">Save</button>
                <a class="btn btn-danger" href="/nodes">Cancel</a>
            </div>
        </form>
    </div>
</div>
<hr>
<div class="card">
    <div class="card-header">
        <h5>List of decision-maker for Decision Problem: <?php echo e($descr); ?></h5>
    </div>

    <div class="card">
        <div class="card-body">
            <table class="table">
                <thead class="thead-light">
                    <tr>
                        <th style="width:5%"></th>
                        <th style="width:75%">Decision-maker</th>
                        <th>Weight</th>
                        <th colspan="2" align="center">Actions</th>
                    </tr>
                </thead>
                <tr>
                    <td>
                        <?php if(Auth::user()->avatar == "none"): ?>
                        <img class="rounded-circle" width="25" height="25" src="<?php echo e(asset('images/ahp.jpg')); ?>">
                        <?php else: ?>
                        <img class="rounded-circle" width="25" height="25" src="<?php echo e(Auth::user()->avatar); ?>">
                        <?php endif; ?>
                    </td>
                    <td><?php echo e(Auth::user()->email); ?></td>
                    <td align="center"><?php echo e(round($ow,3)); ?></td>
                    <td>-</td>
                    <td>-</td>
                </tr>

                <?php $__currentLoopData = $dms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php if($dm['avatar'] == null || $dm['avatar'] == "none"): ?>
                        <img class="rounded-circle" width="25" height="25" src="<?php echo e(asset('images/ahp.jpg')); ?>">
                        <?php else: ?>
                        <img class="rounded-circle" width="25" height="25" src="<?php echo e($dm['avatar']); ?>"> 
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($dm['email']); ?></td>
                    <td align="center">
                        <?php echo e(round($dm['weight'],3)); ?>

                    </td>
                    <td>
                        <a href="/dmcompare/<?php echo e($id); ?>/<?php echo e($dm['id']); ?>" value="Compare the relevance of this decision-maker with the others for this decision problem"><img width="25" height="25" src="<?php echo e(asset('images/decision.png')); ?>"></a>
                    </td>
                    <td>
                        <a href="#" value="Delete this decision-maker and all his judments for this decision problem"><img width="25" height="25" src="<?php echo e(asset('images/remove.png')); ?>"></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
        </div>
    </div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/objetivos/dmpanel.blade.php ENDPATH**/ ?>