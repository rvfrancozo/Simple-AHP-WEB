<?php $__env->startSection('menu'); ?>

<ul class="navbar-nav mr-auto">

    <?php if(auth()->guard()->guest()): ?>
    <?php if(Route::has('login')): ?>
    <?php endif; ?>

    <?php if(Route::has('register')): ?>
    <?php endif; ?>
    <?php else: ?>

    <li class="nav-item">
        <form method="GET" action="/nodes">
            <?php echo csrf_field(); ?>
            <button style="border:none;background-color:transparent" type="submit" class="nav-link">My Decision Problems</button>
        </form>
    </li>
    &nbsp;&nbsp;&nbsp;&nbsp;
    <li>
        <form method="POST" action="/formCreateNode/0">
            <?php echo csrf_field(); ?>
            <button style="border:none;background-color:transparent" type="submit" class="nav-link">New Decision Problem</button>
        </form>
    </li>
    <?php endif; ?>

</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('conteudo'); ?>
<div class="card">
    <div class="card-header">
        <h5>Add new decision-maker to Decision Problem: <?php echo e($descr); ?></h5>
    </div>
    <div class="card-body">
        <form autocomplete="off" method="POST" action="/createDM/<?php echo e($id); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="descricao">E-mail of new decision-maker:</label>
                <input autocomplete="off" type="text" class="form-control" placeholder="" id="descricao" name="descricao">
                <input autocomplete="off" type=hidden name="level" value="">
            </div>
            <div class="btn-group">
                <button type="submit" class="btn btn-primary">Save</button>
                <a class="btn btn-danger" href="/nodes">Cancel</a>
            </div>
        </form>
    </div>
</div>
<hr>
<div class="card">
    <div class="card-header">
        <h5>List of decision-maker for Decision Problem: <?php echo e($descr); ?></h5>
    </div>
    <?php
    $dmsb = App\Models\GroupDecision::where('node', $id)->get();
    ?>
    <div class="card-body">
        <?php $__currentLoopData = $dmsb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($dm['email']); ?>

        <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/objetivos/dmpanel.blade.php ENDPATH**/ ?>