<?php $__env->startSection('menu'); ?>

<ul class="navbar-nav mr-auto">

	<?php if(auth()->guard()->guest()): ?>
	<?php if(Route::has('login')): ?>
	<?php endif; ?>

	<?php if(Route::has('register')): ?>
	<?php endif; ?>
	<?php else: ?>

	<li class="nav-item">
		<form method="GET" action="/nodes">
			<?php echo csrf_field(); ?>
			<button style="border:none;background-color:transparent" type="submit" class="nav-link">My Decision Problems</button>
		</form>
	</li>
	&nbsp;&nbsp;&nbsp;&nbsp;
	<li>
		<form method="POST" action="/formCreateNode/0">
			<?php echo csrf_field(); ?>
			<button style="border:none;background-color:transparent" type="submit" class="nav-link">New Decision Problem</button>
		</form>
	</li>
	<?php endif; ?>

</ul>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('conteudo'); ?>
<?php
$i = 0;
$score = array(1/9, 1/8, 1/7, 1/6, 1/5, 1/4, 1/3, 1/2);
?>
<form method="POST" action="/UpdateScore/<?php echo e($id); ?>">
    <?php echo csrf_field(); ?>
    <?php $__currentLoopData = $goal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <hr><b>In respect to <i><?php echo e($g->descr); ?></i></b>

    <table class="table">
        <tbody>
            <?php $__currentLoopData = $itens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($target[0]->descr); ?> x <?php echo e($c->descr); ?></td>
                <td>
                    <select name="score<?php echo e($i); ?>" class="custom-select">
                        <option value="<?php echo e($g->id); ?>;<?php echo e($target[0]->id); ?>;<?php echo e($c->id); ?>;<?php echo e($score[0]); ?>">1/9 - <?php echo e($c->descr); ?> is very strongly preferable to <?php echo e($target[0]->descr); ?></option>
                        <option value="<?php echo e($g->id); ?>;<?php echo e($target[0]->id); ?>;<?php echo e($c->id); ?>;<?php echo e($score[1]); ?>">1/8 - Intermediate judment</option>
                        <option value="<?php echo e($g->id); ?>;<?php echo e($target[0]->id); ?>;<?php echo e($c->id); ?>;<?php echo e($score[2]); ?>">1/7 - <?php echo e($c->descr); ?> is very strongly preferable to <?php echo e($target[0]->descr); ?></option>
                        <option value="<?php echo e($g->id); ?>;<?php echo e($target[0]->id); ?>;<?php echo e($c->id); ?>;<?php echo e($score[3]); ?>">1/6 - Intermediate judment </option>
                        <option value="<?php echo e($g->id); ?>;<?php echo e($target[0]->id); ?>;<?php echo e($c->id); ?>;<?php echo e($score[4]); ?>">1/5 - <?php echo e($c->descr); ?> is strongly preferable to <?php echo e($target[0]->descr); ?></option>
                        <option value="<?php echo e($g->id); ?>;<?php echo e($target[0]->id); ?>;<?php echo e($c->id); ?>;<?php echo e($score[5]); ?>">1/4 - Intermediate judment </option>
                        <option value="<?php echo e($g->id); ?>;<?php echo e($target[0]->id); ?>;<?php echo e($c->id); ?>;<?php echo e($score[6]); ?>">1/3 - <?php echo e($c->descr); ?> is moderately preferable to <?php echo e($target[0]->descr); ?></option>
                        <option value="<?php echo e($g->id); ?>;<?php echo e($target[0]->id); ?>;<?php echo e($c->id); ?>;<?php echo e($score[7]); ?>">1/2 - Intermediate judment </option>
                        <option value="<?php echo e($g->id); ?>;<?php echo e($target[0]->id); ?>;<?php echo e($c->id); ?>;1" selected>1 - <?php echo e($target[0]->descr); ?> is indifferent to <?php echo e($c->descr); ?></option>
                        <option value="<?php echo e($g->id); ?>;<?php echo e($target[0]->id); ?>;<?php echo e($c->id); ?>;2">2 - Intermediate judment </option>
                        <option value="<?php echo e($g->id); ?>;<?php echo e($target[0]->id); ?>;<?php echo e($c->id); ?>;3">3 - <?php echo e($target[0]->descr); ?> is moderately preferable to <?php echo e($c->descr); ?> </option>
                        <option value="<?php echo e($g->id); ?>;<?php echo e($target[0]->id); ?>;<?php echo e($c->id); ?>;4">4 - Intermediate judment</option>
                        <option value="<?php echo e($g->id); ?>;<?php echo e($target[0]->id); ?>;<?php echo e($c->id); ?>;5">5 - <?php echo e($target[0]->descr); ?> is strongly preferable to <?php echo e($c->descr); ?> </option>
                        <option value="<?php echo e($g->id); ?>;<?php echo e($target[0]->id); ?>;<?php echo e($c->id); ?>;6">6 - Intermediate judment</option>
                        <option value="<?php echo e($g->id); ?>;<?php echo e($target[0]->id); ?>;<?php echo e($c->id); ?>;7">7 - <?php echo e($target[0]->descr); ?> is very strongly preferable to <?php echo e($c->descr); ?> </option>
                        <option value="<?php echo e($g->id); ?>;<?php echo e($target[0]->id); ?>;<?php echo e($c->id); ?>;8">8 - Intermediate judment</option>
                        <option value="<?php echo e($g->id); ?>;<?php echo e($target[0]->id); ?>;<?php echo e($c->id); ?>;9">9 - <?php echo e($target[0]->descr); ?> is extremely preferable to <?php echo e($c->descr); ?> </option>
                    </select>
                </td>
            </tr>
            <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!--<hr>-->
    <div class="btn-group">
        <button type="submit" class="btn btn-primary">Save</button>
        <a class="btn btn-danger" href="/nodes">Cancel</a>
    </div>
    <input type="hidden" name="counter" value="<?php echo e($i); ?>">
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/objetivos/comparisons.blade.php ENDPATH**/ ?>