<?php $__env->startSection('menu'); ?>

<ul class="navbar-nav mr-auto">

  <?php if(auth()->guard()->guest()): ?>
  <?php if(Route::has('login')): ?>
  <?php endif; ?>

  <?php if(Route::has('register')): ?>
  <?php endif; ?>
  <?php else: ?>

  <li class="nav-item">
    <form method="GET" action="/nodes">
      <?php echo csrf_field(); ?>
      <button style="border:none;background-color:transparent" type="submit" class="nav-link">My Decision Problems</button>
    </form>
  </li>
  &nbsp;&nbsp;&nbsp;&nbsp;
  <li>
    <form method="POST" action="/formCreateNode/0">
      <?php echo csrf_field(); ?>
      <button style="border:none;background-color:transparent" type="submit" class="nav-link">New Decision Problem</button>
    </form>
  </li>
  <?php endif; ?>

</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<div class="card">
  <div class="card-header">
    <h3>Criteria from Decision Problem: <?php echo e($goal->descr); ?></h3>

  </div>
  <div class="card-body">
    <table class="table">
      <thead class="thead-light">
        <tr>
          <th>#</th>
          <th>Description</th>
          <th>Operations</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($c->id); ?></td>
          <td><?php echo e($c->descr); ?></td>
          <td>
            <div class="btn-group">
              <a class="btn btn-sm btn-primary" href="\comparisons\<?php echo e($goal->id); ?>\<?php echo e($c->id); ?>">Comparisons</a>
              <button type="button" disabled class="btn btn-sm btn-danger" data-toggle="modal" data-target="#excluir_<?php echo e($c->id); ?>">Remove</button>

              <!-- Modal aqui -->
              <!-- The Modal -->
              <div class="modal" id="excluir_<?php echo e($c->id); ?>">
                <div class="modal-dialog">
                  <div class="modal-content">

                    <!-- Modal Header -->
                    <div class="modal-header">
                      <h4 class="modal-title">Are you sure? #<?php echo e($c->id); ?>?</h4>
                      <button type="button" class="close" data-dismiss="modal"></button>
                    </div>

                    <!-- Modal body -->
                    <div class="modal-body">
                      <strong>Description:</strong> <?php echo e($c->descr); ?>

                    </div>

                    <!-- Modal footer -->
                    <div class="modal-footer">
                      <div class="btn-group">
                        <button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
                        <a class="btn btn-danger" href="/criterio/<?php echo e($c->id); ?>/excluir">Remove</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <div>
      <hr>


      <div class="btn-group">
        <?php if(count($criteria)==0): ?>
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#rexcluir_<?php echo e($goal->id); ?>">New Criterion</button>
        <?php endif; ?>

        <!-- Modal aqui -->
        <!-- The Modal -->
        <div class="modal" id="rexcluir_<?php echo e($goal->id); ?>">
          <div class="modal-dialog">
            <div class="modal-content">

              <!-- Modal Header -->
              <div class="modal-header">
                <h4 class="modal-title">How many criteria would you like to add? (at least two)</h4>
                <button type="button" class="close" data-dismiss="modal"></button>
              </div>

              <!-- Modal body -->
              <div class="modal-body">
                <form method="POST" action="/formCreateNode/<?php echo e($goal->id); ?>">
                  <?php echo csrf_field(); ?>
                  <div class="form-group">
                    <label for="descricao">Name:</label>
                    <select class="custom-select" name="nodes">
                      <option value="2">2</option>
                      <option value="3">3</option>
                      <option value="4">4</option>
                      <option value="5">5</option>
                      <option value="6">6</option>
                      <option value="7">7</option>
                      <option value="8">8</option>
                      <option value="9">9</option>
                      <option value="10">10</option>
                      <option value="10">11</option>
                      <option value="10">12</option>
                      <option value="10">13</option>
                      <option value="10">14</option>
                      <option value="10">15</option>
                    </select>
                  </div>
                  <div class="btn-group">
                    <button type="submit" class="btn btn-primary">Go</button>
                    <a class="btn btn-danger" href="/nodes">Cancel</a>
                  </div>
                  <input type="hidden" name="type" value="1">
                </form>
              </div>

              <!-- Modal footer -->
              <div class="modal-footer">
                <div class="btn-group">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>


    </div>
  </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/defaultwebsite/resources/views/objetivos/criteria.blade.php ENDPATH**/ ?>